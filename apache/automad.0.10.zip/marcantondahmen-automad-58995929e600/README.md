#Automad

*A file-based content management system*

---

The full documentation and feature list can be found at http://automad.org.   
The API reference is available at http://api.automad.org.   

---

This is a publish-only repository and all pull requests are ignored.

---

Automad is released under the [MIT license](http://automad.org/license).   

---

© 2014 [Marc Anton Dahmen](http://marcdahmen.de)