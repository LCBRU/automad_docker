<?php defined('AUTOMAD') or die('Direct access not permitted!'); ?>
@i(elements/header.php)

	<div class="container">
		
		<div class="row">
			<div id="title" class="col-md-6">
				<h1>@p(title)</h1>
				<h2><a href="/">Go back ...</a></h2>
			</div>
		</div>
		
	</div>

@i(elements/footer.php)