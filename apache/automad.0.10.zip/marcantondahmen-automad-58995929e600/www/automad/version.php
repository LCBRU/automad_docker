<?php define('AM_VERSION', '0.10.0'); ?>
